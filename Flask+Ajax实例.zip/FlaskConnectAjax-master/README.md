# FlaskConnectAjax
Flask与ajax（jQuery）交互的几种方法：post、get、getJSON、load、ajax
